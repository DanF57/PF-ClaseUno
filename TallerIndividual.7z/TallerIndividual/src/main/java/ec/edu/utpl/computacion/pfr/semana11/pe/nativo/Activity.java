package ec.edu.utpl.computacion.pfr.semana11.pe.nativo;

import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.Function;
import java.util.function.Predicate;

public class Activity {
        public static void main(String[] args) throws InterruptedException {
            SubmissionPublisher<String> publisher = new SubmissionPublisher<>();

            //Crear el subscriber para imprimir
            PrinterSubscriber<Double> printerSubscriber = new PrinterSubscriber<>();

            //Función convertir de texto a número real
            Function<String, Double> toDouble = x -> Double.parseDouble(x.substring(x.lastIndexOf(":") + (1)));

            //Función filtrar texto que es número
            Predicate<Double> predicate = x -> x > 21;

            //Para filtrar
            FilterProcessor<Double, Double> greaterT = new FilterProcessor<>(predicate);

            //Para mapear
            MapProcessor<String, Double> mapDoubleValues = new MapProcessor<>(toDouble);

            //Flujo
            publisher.subscribe(mapDoubleValues);
            mapDoubleValues.subscribe(greaterT);
            greaterT.subscribe(printerSubscriber);

            List<String> items = List.of("TERM_1:22", "TERM_2:36", "TERM_3:19.7", "TERM_4:28.1", "TERM_5:22");
            //Enviar los datos a los suscritores
            items.forEach(publisher::submit);

            Thread.sleep( 2 * 1000);

            publisher.close();
        }
    }
