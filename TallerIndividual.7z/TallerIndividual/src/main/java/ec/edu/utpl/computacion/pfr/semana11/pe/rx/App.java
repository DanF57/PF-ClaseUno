package ec.edu.utpl.computacion.pfr.semana11.pe.rx;

import io.reactivex.rxjava3.core.Observable;
import org.apache.commons.lang3.StringUtils;
import java.util.List;

public class App {
    public static void main(String[] args) throws InterruptedException {
        List<String> items = List.of("100", "Quito", "300", "Loja", "400", "Guayaquil");
        Observable.fromIterable(items)
                .filter(StringUtils::isNumeric)
                .map(Integer::valueOf)
                .subscribe(System.out::println);

        Thread.sleep(1 * 1000);
    }
}