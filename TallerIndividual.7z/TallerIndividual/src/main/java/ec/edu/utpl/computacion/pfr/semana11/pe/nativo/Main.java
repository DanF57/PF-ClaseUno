package ec.edu.utpl.computacion.pfr.semana11.pe.nativo;

import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.Function;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args)  throws InterruptedException {
        SubmissionPublisher<String> publisher = new SubmissionPublisher<>();

        //Crear el subscriber para imprimir
        PrinterSubscriber<Integer> printerSubscriber = new PrinterSubscriber<>();

        //Función convertir de texto a número real
        Function<String, Integer> toDouble = Integer::valueOf;

        //Función filtrar texto que es número
        Predicate<String> predicate = StringUtils::isNumeric;

        //Para filtrar
        FilterProcessor<String, String> onlyNumbersFilter = new FilterProcessor<>(predicate);

        //Para mapear
        MapProcessor<String, Integer> map2IntProcessor = new MapProcessor<>(toDouble);

        //Flujo
        publisher.subscribe(onlyNumbersFilter);
        onlyNumbersFilter.subscribe(map2IntProcessor);
        map2IntProcessor.subscribe(printerSubscriber);


        List<String> items = List.of("100", "Quito", "300", "Loja", "400", "Guayaquil");
        //Enviar los datos a los suscritores
        items.forEach(publisher::submit);

        Thread.sleep(1 * 1000);

        publisher.close();
    }
}